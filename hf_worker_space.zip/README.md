---
title: Vibe worker
emoji: 🎵
sdk: gradio
app_file: app.py
pinned: false
---

Vibe Music — воркер скачиваний (фоновая очередь Neon). Страница — только статус.
