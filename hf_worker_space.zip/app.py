# -*- coding: utf-8 -*-
"""Vibe worker как Gradio Space: воркерdownloads в фоновом потоке,
Gradio — страница статуса (HF требует живой порт, UI показывает build)."""
import asyncio
import os
import sys
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

_worker_log = []
_build = "?"

def _start_worker():
    global _build
    try:
        import run_worker as rw
        _build = rw.WORKER_BUILD
        _worker_log.append(f"воркер {rw.WORKER_BUILD} запускается…")
        asyncio.run(rw.main())
    except SystemExit as e:
        _worker_log.append(f"воркер остановлен (exit {e.code}): нет BOT_TOKEN/DATABASE_URL?")
    except Exception as e:  # noqa: BLE001
        _worker_log.append(f"воркер упал: {type(e).__name__}: {e}")

t = threading.Thread(target=_start_worker, name="vibe-worker", daemon=True)
t.start()

import gradio as gr


def status():
    lines = [f"Vibe worker — build {_build}",
             "роль: скачивания из очереди Neon (Botkeep/HF/Render)",
             f"живых потоков: {threading.active_count()}",
             * _worker_log[-3:]]
    return "\n".join(lines)


demo = gr.Interface(fn=status, inputs=None,
                    outputs=gr.Textbox(label="Статус воркера"),
                    title="Vibe Music — worker",
                    description="Не обращай внимания на эту страницу: она просто держит Space живым. Воркер качает треки в фоне.")
demo.queue(api_open=False).launch(server_name="0.0.0.0",
                                  server_port=int(os.environ.get("PORT", 7860)),
                                  show_api=False)
