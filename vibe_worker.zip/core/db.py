"""Асинхронный движок SQLAlchemy + фабрика сессий.

База выбирается так:
- DATABASE_URL из окружения → Postgres (Neon/Supabase; облако-деплой);
- иначе локальный SQLite (data/music.db), как раньше.
"""
import os
import ssl as ssl_mod

from sqlalchemy import event
from sqlalchemy.ext.asyncio import (AsyncEngine, AsyncSession, async_sessionmaker,
                                    create_async_engine)

from .config import settings


def _database_url() -> str:
    url = os.getenv("DATABASE_URL", "").strip()
    if not url:
        return f"sqlite+aiosqlite:///{settings.DB_PATH}"
    # Neon/Supabase отдают postgres:// — приводим к диалекту asyncpg
    for prefix in ("postgresql://", "postgres://"):
        if url.startswith(prefix):
            url = "postgresql+asyncpg://" + url[len(prefix):]
            break
    return url


def create_engine() -> AsyncEngine:
    url = _database_url()
    if url.startswith("postgresql+asyncpg"):
        from urllib.parse import parse_qsl, urlencode, urlunparse, urlparse
        p = urlparse(url)
        q = dict(parse_qsl(p.query))
        server_settings: dict | None = None
        if "options" in q:
            # Neon через релей без SNI: endpoint передаётся
            # в startup-пакете как options=endpoint%3D<endpoint-id>
            server_settings = {"options": q.pop("options")}
        sslmode = q.pop("sslmode", None)
        q.pop("channel_binding", None)
        url = urlunparse((p.scheme, p.netloc, p.path, p.params, urlencode(q), p.fragment))
        kwargs: dict = {"echo": False, "pool_pre_ping": True}
        if sslmode or server_settings:
            ctx = ssl_mod.create_default_context()
            if (p.hostname or "") in ("127.0.0.1", "localhost", "::1"):
                # релей туннелирует до настоящего Neon: имя 127.0.0.1 не совпадает
                # с сертом, но цепочку CA всё равно проверяем
                ctx.check_hostname = False
            connect_args: dict = {"ssl": ctx}
            if server_settings:
                connect_args["server_settings"] = server_settings
            kwargs["connect_args"] = connect_args
        return create_async_engine(url, **kwargs)
    return create_async_engine(url, echo=False)


engine: AsyncEngine = create_engine()

if engine.dialect.name == "sqlite":
    @event.listens_for(engine.sync_engine, "connect")
    def _sqlite_pragma(dbapi_conn, _rec):
        """WAL + busy_timeout: почти не возникает 'database is locked'
        при одновременной работе бота и сервера с одной базой."""
        cur = dbapi_conn.cursor()
        cur.execute("PRAGMA journal_mode=WAL")
        cur.execute("PRAGMA synchronous=NORMAL")
        cur.execute("PRAGMA busy_timeout=30000")
        cur.close()

AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

async def get_session() -> AsyncSession:
    """Сессия для FastAPI Depends."""
    async with AsyncSessionLocal() as session:
        yield session

async def init_db() -> None:
    from .models import Base
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    # мини-миграция: create_all не добавляет колонки в существующие таблицы
    from sqlalchemy import text
    col = "ALTER TABLE playlists ADD COLUMN {ifnot}source VARCHAR(16) NOT NULL DEFAULT ''"
    try:
        async with engine.begin() as conn:
            if engine.dialect.name == "postgresql":
                await conn.execute(text(col.format(ifnot="IF NOT EXISTS ")))
            else:
                await conn.execute(text(col.format(ifnot="")))
    except Exception:
        pass
    # Импортированный плейлист — обычный плейлист коллекции (решение юзера):
    # снимаем касту «import», он больше ничем не отличается от собранного.
    try:
        async with engine.begin() as conn:
            await conn.execute(text("UPDATE playlists SET source = '' WHERE source = 'import'"))
    except Exception:
        pass
    # Wave (М1): на старых базах может не быть 18+-флага трека.
    # Postgres не приводит целочисленный литерал к BOOLEAN (DEFAULT 0/1 →
    # «default expression is of type integer»), SQLite же принимает что угодно.
    is_pg = engine.dialect.name == "postgresql"
    explicit_dflt = "FALSE" if is_pg else "0"
    try:
        async with engine.begin() as conn:
            await conn.execute(text(
                f"ALTER TABLE tracks ADD COLUMN explicit BOOLEAN NOT NULL DEFAULT {explicit_dflt}"))
    except Exception:
        pass
    # Wave v2 (интеллект): сценарий и контекст сессии
    for stmt in ("ALTER TABLE wave_sessions ADD COLUMN scenario JSON",
                 "ALTER TABLE wave_sessions ADD COLUMN context JSON"):
        try:
            async with engine.begin() as conn:
                await conn.execute(text(stmt))
        except Exception:
            pass
    # Wave v2: переключатель контекстной персонализации
    ctx_dflt = "TRUE" if is_pg else "1"
    try:
        async with engine.begin() as conn:
            await conn.execute(text(
                "ALTER TABLE wave_settings ADD COLUMN context_enabled BOOLEAN NOT NULL DEFAULT " + ctx_dflt))
    except Exception:
        pass
    # Источники 12+: официальная страница и лицензия трека (TEXT валиден
    # и на Postgres, и на SQLite; на PG добавляем IF NOT EXISTS)
    for col_ddl in ("ALTER TABLE tracks ADD COLUMN {ifnot}page_url TEXT",
                    "ALTER TABLE tracks ADD COLUMN {ifnot}license VARCHAR(64)"):
        try:
            async with engine.begin() as conn:
                await conn.execute(text(
                    col_ddl.format(ifnot="IF NOT EXISTS " if is_pg else "")))
        except Exception:
            pass
    # Local-first (§17): идемпотентные офлайн-события истории — event_id
    # + уникальная пара (user_id, event_id) для дедупликации на сервере.
    try:
        async with engine.begin() as conn:
            await conn.execute(text(
                "ALTER TABLE play_events ADD COLUMN {ifnot}event_id VARCHAR(48)".format(
                    ifnot="IF NOT EXISTS " if is_pg else "")))
    except Exception:
        pass
    # Цензурный детектор: заливка с мутами/бипами («замученная») не отдаётся
    # ни плеером, ни в чат — флаг ставится после анализа файла.
    try:
        async with engine.begin() as conn:
            await conn.execute(text(
                ("ALTER TABLE tracks ADD COLUMN {ifnot}censored "
                 "BOOLEAN NOT NULL DEFAULT {dflt}").format(
                    ifnot="IF NOT EXISTS " if is_pg else "",
                    dflt="FALSE" if is_pg else "0")))
    except Exception:
        pass
    # Аудио-анализ: BPM/энергия/валентность/танцевальность + отметка времени.
    # analyzed_at NULL означает «ещё не анализировали» (бэкфилл scan_features).
    for col_ddl in ("ALTER TABLE tracks ADD COLUMN {ifnot}bpm FLOAT NOT NULL DEFAULT 0",
                    "ALTER TABLE tracks ADD COLUMN {ifnot}energy FLOAT NOT NULL DEFAULT 0",
                    "ALTER TABLE tracks ADD COLUMN {ifnot}valence FLOAT NOT NULL DEFAULT 0",
                    "ALTER TABLE tracks ADD COLUMN {ifnot}danceability FLOAT NOT NULL DEFAULT 0",
                    "ALTER TABLE tracks ADD COLUMN {ifnot}analyzed_at TIMESTAMP"):
        try:
            async with engine.begin() as conn:
                await conn.execute(text(
                    col_ddl.format(ifnot="IF NOT EXISTS " if is_pg else "")))
        except Exception:
            pass
    try:
        async with engine.begin() as conn:
            await conn.execute(text(
                "CREATE UNIQUE INDEX IF NOT EXISTS ix_play_events_user_event "
                "ON play_events (user_id, event_id)"))
    except Exception:
        pass

    # Биллинг v2 (два тира Lite/Pro): старые таблицы были без колонки tier.
    # Фича существовала меньше суток, реальных подписок/платежей нет —
    # PG: снимаем констрейнт и добавляем tier; SQLite (дев-база): дропаем
    # устаревшие таблицы (после миграций create_all пересоздаёт их заново).
    try:
        async with engine.begin() as conn:
            if is_pg:
                await conn.execute(text(
                    "ALTER TABLE subscriptions DROP CONSTRAINT IF EXISTS subscriptions_user_id_key"))
                await conn.execute(text(
                    "ALTER TABLE subscriptions ADD COLUMN IF NOT EXISTS tier VARCHAR(16) NOT NULL DEFAULT 'pro'"))
                await conn.execute(text(
                    "CREATE UNIQUE INDEX IF NOT EXISTS uq_sub_user_tier ON subscriptions (user_id, tier)"))
                await conn.execute(text(
                    "ALTER TABLE subscriptions ALTER COLUMN expires_at DROP NOT NULL"))
            else:
                for tbl in ("subscriptions", "star_payments"):
                    cols = (await conn.execute(
                        text(f"PRAGMA table_info({tbl})"))).mappings().all()
                    old = cols and not any(c["name"] == "tier" for c in cols)
                    # subscriptions: ещё и expires_at NOT NULL (до вечных подписок)
                    exp = next((c for c in cols if c["name"] == "expires_at"), None)
                    nn = tbl == "subscriptions" and exp is not None and exp["notnull"] == 1
                    if cols and (old or nn):
                        await conn.execute(text(f"DROP TABLE {tbl}"))
    except Exception:  # noqa: BLE001
        logging.getLogger("server").exception("billing: миграция subscriptions")
    # пересоздание дропнутых/новых таблиц после миграций
    try:
        async with engine.begin() as conn:
            from .models import Base as _B
            await conn.run_sync(_B.metadata.create_all)
    except Exception:  # noqa: BLE001
        logging.getLogger("server").exception("billing: пересоздание таблиц")
