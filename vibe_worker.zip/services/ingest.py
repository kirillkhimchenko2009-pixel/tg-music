"""Инжест треков: превращает TrackMeta (откуда угодно) в скачанный файл + запись в каталоге."""
import asyncio
import logging
import re
from dataclasses import dataclass
from pathlib import Path

from sqlalchemy.ext.asyncio import AsyncSession

from core.config import settings
from core.models import Track
from services import matching, pipeline
from services import censor as censor_mod
from services.authstore import get_token
from services.providers.base import TrackMeta
from services.providers.youtube import YouTubeProvider
from services.providers import zvuk as zv
from services.providers import zaycev as zay
from services.providers import hitmoz as hzm
from services.providers import hotplayer as hpl
from services.providers import mp3party as mpp
from services.providers import promodj as pdj
from services.providers import audius as aud
from services.providers import ccmixter as ccm
from services.providers import saavn as svn
from services.providers.yandex import YandexProvider
from services.providers import soundcloud as scc

yt = YouTubeProvider()
log = logging.getLogger("ingest")

@dataclass
class Resolved:
    track: Track | None
    file_path: Path | None
    quality: str | None
    status: str                     # cached | downloaded | not_found
    error: str | None = None

async def _candidates(session: AsyncSession, user_id: int | None,
                      meta: TrackMeta, quality: str) -> list[tuple[TrackMeta, str]]:
    """Цепочка вариантов: свои источники по токенам → Звук → ЯМ → YouTube Music.
    Возвращает [(вариант_meta, token_или_''), ...]."""
    out: list[tuple[TrackMeta, str]] = []
    query = f"{meta.artist} {meta.title}".strip()

    # Свой источник — первым, но цепочку НЕ заканчиваем: если ЯМ/Звук не отдали
    # файл (нет аудио в каталоге, права, регион), подключаются фолбэки ниже.
    if meta.source == "zvuk":
        tok = await get_token(session, user_id, "zvuk")
        if tok:
            out.append((meta, tok))
    if meta.source == "yandex":
        tok = await get_token(session, user_id, "ym")
        if tok:
            # 18+: у ЯМ бывают «чистые» заливки (слова замазаны/запиканы) —
            # по решению юзера такое не отдаём вовсе: ЯМ-вариант исключён,
            # только оригинал с zaycev; дальше цепочку продолжат
            # zvuk/прямые сайты/YouTube.
            if not getattr(meta, "explicit", False):
                out.append((meta, tok))
            else:
                zc = await _zaycev_original(query, meta)
                if zc:
                    log.info("18+: скачиваю оригинал с zaycev (%s); ЯМ исключён",
                             zc.display())
                    out.append((zc, ""))
    if meta.source in ("soundcloud", "zaycev", "hitmoz", "hotplayer", "mp3party",
                       "promodj", "audius", "ccmixter"):
        # собственный вариант — тоже кандидат: permalink/страница скачивается
        # напрямую (SC — HLS, RU-сайты — download_url). Без этого цепочка
        # качает «похожее с других сайтов» или честно падает с not_found.
        out.append((meta, ""))

    # 1) Звук (если есть токен — там лучше качество, вплоть до FLAC)
    zv_tok = await get_token(session, user_id, "zvuk")
    if zv_tok and meta.source != "zvuk":
        try:
            cands = await zv.search(query, limit=6, token=zv_tok)
            m = matching.best_match(meta, cands)
            if m:
                out.append((m, zv_tok))
        except Exception:
            pass

    # 2) Яндекс Музыка (если есть токен и это не сам-источник)
    ym_tok = await get_token(session, user_id, "ym")
    if ym_tok and meta.source != "yandex":
        try:
            prov = YandexProvider(ym_tok)
            cands = await prov.search(query, limit=6)
            m = matching.best_match(meta, cands)
            # guard по названию и в строгом матче: цельное «артист название»
            # завышает скор при длинном имени артиста — иначе предложит
            # совершенно чужой трек того же исполнителя
            if m and _title_sim(meta.title, m.title) < 0.55:
                log.info("ям: кандидат %s отвергнут по названию (%.2f) для %s",
                         m.display(), _title_sim(meta.title, m.title),
                         meta.display())
                m = None
            if not m and cands:
                # широкий фолбэк: точное название может не пройти строгий порог
                # (транслит/фиты/издания) — берём лучшее по схожести, но строго
                # по артисту, чтобы не подсовывать песню чужого исполнителя
                pool = list(cands)
                q2 = _clean_query(query)
                if q2 and q2.lower() != query.lower().strip():
                    try:
                        pool += await prov.search(q2, limit=6)
                    except Exception:
                        pass
                m = matching.best_match(meta, pool, min_score=0.45)
                # «artist title» целиком завышает скор на общем имени артиста —
                # поэтому дополнительно требовать похожести самого названия
                if m and _title_sim(meta.title, m.title) < 0.6:
                    log.info("ям: кандидат %s отвергнут по названию (%.2f) для %s",
                             m.display(), _title_sim(meta.title, m.title),
                             meta.display())
                    m = None
                if m and not hzm.artist_guard(meta, m):
                    log.info("ям: кандидат %s отвергнут по артисту для %s",
                             m.display(), meta.display())
                    m = None
                if m:
                    log.info("широкий ям-матч для %s: %s",
                             meta.display(), m.display())
            if m:
                # 18+: у ЯМ фонограмма может быть «чистой» (слова замазаны) —
                # по решению юзера ЯМ-вариант исключаем: только оригинал
                # с zaycev, иначе цепочку продолжат другие источники
                if getattr(m, "explicit", False):
                    zc = await _zaycev_original(query, meta)
                    if zc:
                        log.info("18+: ставлю первичным оригинал zaycev "
                                 "(%s); ЯМ исключён", zc.display())
                        out.append((zc, ""))
                else:
                    out.append((m, ym_tok))
        except Exception:
            log.exception("поиск на яндексе не удался")

    # 2.5) Прямые RU-сайты без токенов (быстрее YT): zaycev.net (mp3-320) →
    #      hotplayer/mp3party → hitmoz в конце (его поиск постоянно крутит
    #      внутренние ретраи и упирается в потолок без результатов).
    #      Международные бесплатные: promodj (DJ-миксы, per-track download),
    #      audius (негейтованные), ccmixter (CC-материал).
    for prov, name in ((zay, "zaycev"), (svn, "saavn"), (scc, "soundcloud"),
                       (pdj, "promodj"), (ccm, "ccmixter"),
                       (aud, "audius"),
                       (hpl, "hotplayer"), (mpp, "mp3party"),
                       (hzm, "hitmoz")):
        try:
            # жёсткий потолок на поиск: сайты с внутренними ретраями (hitmoz
            # ловил 19.6 с без результатов) тормозили всю цепочку кандидатов
            cands = await asyncio.wait_for(prov.search(query, limit=6), 10)
            m = matching.best_match(meta, cands, min_score=0.55)
            # guard по артисту — иначе сайты подсовывают однофамильцев/тёзок
            if m and not hzm.artist_guard(meta, m):
                log.info("%s: кандидат %s отвергнут по артисту", name, m.display())
                m = None
            # источники без длительности (mp3party) рискованно полагаться только
            # на общий скор: «…Smell Like…» ловит чужие вариации названия
            if m and not m.duration and _title_sim(meta.title, m.title) < 0.6:
                log.info("%s: кандидат %s отвергнут по названию "
                         "(длительности нет)", name, m.display())
                m = None
            if m:
                out.append((m, ""))
        except Exception:
            log.exception("поиск на %s не удался", name)

    # 3) YouTube Music: для ytmusic-источника сам трек — последний запасной
    #    вариант (с зарубежных IP YouTube часто ловит бот-чек, RU-сайты выше надёжнее)
    if meta.source == "ytmusic":
        out.append((meta, ""))
    else:
        try:
            out.extend(await _yt_candidates(meta, query))
        except Exception:
            log.exception("yt-поиск упал для %s", meta.display())
    return out


_JUNK = re.compile(r"\((?:[^)]*(?:feat|ft\.|official|video|audio|lyric|remaster|live)[^)]*)\)"
                   r"|\[[^\]]*\]|\s+feat\.?\s+.+$", re.IGNORECASE)


def _clean_query(q: str) -> str:
    q = _JUNK.sub(" ", q)
    return re.sub(r"\s+", " ", q).strip(" -–—:,")


def _title_sim(a: str, b: str) -> float:
    """Схожесть только названий: общий текст a+b завышает скор, когда
    артист длинный (префикс всегда совпадает)."""
    import difflib
    from services.matching import norm
    return difflib.SequenceMatcher(None, norm(a), norm(b)).ratio()


async def _zaycev_original(query: str, meta: TrackMeta) -> TrackMeta | None:
    """Оригинальная фонограмма с zaycev.net. У ЯМ express-треки с меткой 18+
    иногда залиты в «чистом» варианте (слова замазаны) — zaycev отдаёт
    издательские оригиналы."""
    from services.providers.hitmoz import artist_guard
    try:
        cands = await zay.search(_clean_query(query), limit=6)
        m = matching.best_match(meta, cands, min_score=0.55)
        if m and _title_sim(meta.title, m.title) < 0.6:
            m = None
        if m and not artist_guard(meta, m):
            m = None
        if m and meta.duration and m.duration \
                and abs(meta.duration - m.duration) > 10:
            log.info("zaycev-оригинал: расхождение длительности (%s vs %s с) — отбой",
                     m.duration, meta.duration)
            m = None
        return m
    except Exception:
        return None


async def _yt_candidates(meta: TrackMeta, query: str) -> list[tuple[TrackMeta, str]]:
    """Строгий матч (0.55) по обычному и очищенному запросу; затем широкий порог
    (0.42) как последний шанс; в конце добавляем запасного кандидата — если у
    первого упадёт yt-dlp, батч попробует его вместо пропуска."""
    out: list[tuple[TrackMeta, str]] = []
    queries = [query]
    q2 = _clean_query(query)
    if q2 and q2.lower() != query.lower().strip():
        queries.append(q2)
    pool: list[TrackMeta] = []
    for q in queries:
        try:
            # ytmusicapi fallback'ит на yt-dlp-процесс — без потолка он висит
            # на чёрной дыре сети и тянет всю цепочку кандидатов
            cands = await asyncio.wait_for(yt.search(q, limit=6), 30)
        except Exception:
            cands = []
        pool.extend(cands)
        m = matching.best_match(meta, cands, min_score=0.55)
        if m:
            out.append((m, ""))
            break
    if not out and pool:
        m = matching.best_match(meta, pool, min_score=0.42)
        if m:
            log.info("широкий матч для %s: %s", meta.display(), m.display())
            out.append((m, ""))
    if out:
        rest = [c for c in pool if c.external_id != out[0][0].external_id]
        scored = sorted(((matching.similarity(meta, c), c) for c in rest),
                        key=lambda x: x[0], reverse=True)
        if scored and scored[0][0] >= 0.5:
            out.append((scored[0][1], ""))
    return out

async def resolve(session: AsyncSession, meta: TrackMeta, quality: str,
                  user_id: int | None = None, on_progress=None,
                  allow_cached: bool = True) -> Resolved:
    # 1) Трек уже в каталоге с кешем file_id?
    track = await _upsert(session, meta)
    # «замученную» заливку (детектор пометил censored) из кеша не отдаём —
    # честно пересобираем из других источников
    if allow_cached and track.file_id and not getattr(track, "censored", False):
        return Resolved(track=track, file_path=None, quality=track.quality, status="cached")

    # Уже скачан локально, но файл ещё не залит в ТГ
    if (track.local_path and not getattr(track, "censored", False)
            and Path(track.local_path).exists()):
        return Resolved(track=track, file_path=Path(track.local_path),
                        quality=track.quality, status="downloaded")

    # 2) Выбор источника и скачивание
    chain = await _candidates(session, user_id, meta, quality)
    if not chain:
        err = ("по запросу не нашлось совпадений (YouTube без токена; "
               "ЯМ/Звук дадут лучше, если добавить токен /token)")
        log.warning("skip %s: %s", meta.display(), err)
        return Resolved(track=track, file_path=None, quality=None,
                        status="not_found", error=err)

    bad: dict | None = None            # наименее зацензуренный кандидат
    for dl_meta, token in chain:
        # если этот источник уже качался раньше и файл кеширован в ТГ —
        # отдаём мгновенно (иначе повторное нажатие «скачать» снова гоняет
        # весь конвейер пару минут, а юзер видит «вечную загрузку»)
        prev = await _upsert(session, dl_meta)
        if prev.id != track.id:
            if prev.file_id and not getattr(prev, "censored", False):
                return Resolved(track=prev, file_path=None,
                                quality=prev.quality, status="cached")
            local_p = (Path(prev.local_path) if prev.local_path and
                       not getattr(prev, "censored", False) else None)
            if local_p and local_p.exists():
                return Resolved(track=prev, file_path=local_p,
                                quality=prev.quality, status="downloaded")
        res = await pipeline.download(dl_meta, quality, token, on_progress=on_progress)
        if not res:
            log.warning("skip %s: скачивание не удалось на %-6s (%s)",
                        meta.display(), dl_meta.source, dl_meta.display())
            continue
        # 18+: проверяем фонограмму на «замученность» (муты/бипы цензуры) —
        # если замучена, пробуем следующий источник, а в конце отдаём
        # наименее зацензуренный вариант (иначе отдали бы тише, но с блюрами)
        chk = await censor_mod.check(res.path.as_posix())
        if chk.get("censored"):
            offenders = chk["beeps"] + chk["mutes"]
            log.warning("ingest: %s из %s похож на цензурную заливку "
                        "(бипы=%s муты=%s) — следующий источник…",
                        dl_meta.display(), dl_meta.source,
                        chk["beeps"], chk["mutes"])
            if bad is None or offenders < bad["offenders"]:
                bad = {"res": res, "meta": dl_meta, "offenders": offenders}
            # файл уже на диске — запоминаем его на строке источника и
            # помечаем censored: повторное «скачать» не отдаст заливку из кеша
            try:
                ctrack = await _upsert(session, dl_meta)
                ctrack.quality = res.quality
                ctrack.size_bytes = res.size_bytes
                ctrack.local_path = res.path.as_posix()
                ctrack.censored = True
                await session.commit()
            except Exception:  # noqa: BLE001
                pass
            continue
        dl_track = await _upsert(session, dl_meta)
        dl_track.quality = res.quality
        dl_track.size_bytes = res.size_bytes
        dl_track.local_path = res.path.as_posix()
        await session.commit()
        # удаляем заглушку из другого источника, если она без файла
        if dl_track.id != track.id and not (track.local_path or track.file_id):
            # заглушку удаляем в SAVEPOINT: FK без CASCADE (playlist_tracks,
            # play_events…) гонит IntegrityError на flush — откатываем только
            # точку, иначе сессия остаётся отравленной (PendingRollbackError)
            try:
                async with session.begin_nested():
                    await session.delete(track)
            except Exception:
                pass
        return Resolved(track=dl_track, file_path=res.path,
                        quality=res.quality, status="downloaded")

    if bad is not None:
        # все источники отдали цензурные заливки — по решению юзера замученную
        # фонограмму НЕ отдаём вовсе (ни в чат, ни в приложение): честный
        # not_found; воркер положит 30-сек фрагмент/ошибку с объяснением.
        # Скачанные заливки остаются на диске с флагом censored (кеш их
        # не отдаёт), чтобы не перекачивать при будущих попытках.
        log.warning("ingest: все источники отдали цензурные заливки — "
                    "не отдаю ничего (%s, %s бипов/мутов)",
                    bad["meta"].display(), bad["offenders"])
        return Resolved(track=None, file_path=None, quality=None,
                        status="not_found",
                        error="доступна только цензурированная версия "
                              "(слова замазаны/запиканы) — оригинал не найден")

    tried = ", ".join(dict.fromkeys(m.source for m, _ in chain))
    err = f"все источники не ответили (пробовали: {tried})"
    log.warning("skip %s: %s", meta.display(), err)
    return Resolved(track=track, file_path=None, quality=None,
                    status="not_found", error=err)

async def _upsert(session: AsyncSession, meta: TrackMeta) -> Track:
    from services.catalog import upsert_track
    return await upsert_track(session, meta)
